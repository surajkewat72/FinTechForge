export interface ErrorResponse {
    error: string;
    message: string;
  }
  