import React from "react";

const About: React.FC = () => {
  return <div>Shogun the Purple Born</div>;
};

export default About;
