import React from "react";

const Features: React.FC = () => {
  return <div>Shogun The Greatest Lord of Seven Heavens</div>;
};

export default Features;
