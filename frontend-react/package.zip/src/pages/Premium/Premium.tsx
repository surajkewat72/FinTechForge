import React from "react";

const Premium: React.FC = () => {
  return <div>Premium Page</div>;
};

export default Premium;
